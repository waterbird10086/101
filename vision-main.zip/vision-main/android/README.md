## Status

The Android demo of TorchVision is currently unmaintained, untested and likely out-of-date.
